import { city } from './common'

let getCitys = () => city;

export {
  getCitys
}
