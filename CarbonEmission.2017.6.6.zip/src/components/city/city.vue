<template>
  <el-row :gutter="12">
    <el-col :span="6">
      <el-table :data="toCitys" highlight-current-row>
        <el-table-column prop="name" label="项目所在城市"></el-table-column>
        <el-table-column prop="value" label="地理坐标"></el-table-column>
      </el-table>
    </el-col>
    <el-col :span="18">
      <el-table border :data="citys">
        <el-table-column prop="name" label="来源城市"></el-table-column>
        <el-table-column prop="location" label="距离"></el-table-column>
      </el-table>
    </el-col>
  </el-row>
</template>
<script>
  import {calcDistance} from '../../api/api'
  import {getCitys} from '../../utils'
  export default{
    data(){
      return {
        toCitys: [
          {name: '南京市', location: ''},
          {name: '无锡市', location: ''},
          {name: '徐州市', location: ''},
          {name: '常州市', location: ''},
          {name: '苏州市', location: ''},
          {name: '南通市', location: ''},
          {name: '连云港市', location: ''},
          {name: '淮安市', location: ''},
          {name: '盐城市', location: ''},
          {name: '扬州市', location: ''},
          {name: '镇江市', location: ''},
          {name: '泰州市', location: ''},
          {name: '宿迁市', location: ''}
        ],
        citys: [
          {name: 'aa', distance: 998}
        ]
      }
    },
    methods: {

    }
  }
</script>
