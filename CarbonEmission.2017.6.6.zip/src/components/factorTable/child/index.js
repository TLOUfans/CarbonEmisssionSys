'use strict'

import DefaultTable from './DefaultTable.vue'
import DefaultForm from './DefaultForm.vue'

export  {
  DefaultTable,
  DefaultForm
};
