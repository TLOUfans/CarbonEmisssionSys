'use strict'

import PnjTable from './view/PnjTable.vue'

export {
  PnjTable
};
