import api from '../../api'
import * as types from '../mutationTypes'

const state = {
  users:[]
}

const actions ={

}

