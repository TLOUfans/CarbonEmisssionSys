import * as types from './mutationTypes'

export const loginedUser = ({commit},product) => {
  commit(types.USER_CODE,"admin");
}
