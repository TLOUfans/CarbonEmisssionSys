export const USER_CODE = 'USER_CODE'
export const USER_NAME = 'USER_NAME'
export const USER_TYPE = 'USER_TYPE'
export const CURRENT_MENU = 'CURRENT_MENU'
